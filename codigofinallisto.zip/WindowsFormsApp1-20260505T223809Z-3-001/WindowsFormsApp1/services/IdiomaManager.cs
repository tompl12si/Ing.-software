﻿using DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace services
{
    public class IdiomaManager : ISubjectIdioma
    {
        private List<IObserverIdioma> _observadores = new List<IObserverIdioma>();
        private Dictionary<string, string> _diccionarioActual = new Dictionary<string, string>();
        private DalIdioma _dalIdioma = new DalIdioma();
        private static IdiomaManager _instancia;
        public static IdiomaManager Instancia
        {
            get
            {
                if (_instancia == null)
                {
                    _instancia = new IdiomaManager();
                }
                return _instancia;
            }
        }
        private IdiomaManager() { }
        public void Suscribir(IObserverIdioma observador)
        {
            if (!_observadores.Contains(observador))
            {
                _observadores.Add(observador);
                if (_diccionarioActual.Count > 0)
                {
                    observador.ActualizarIdioma(_diccionarioActual);
                }
            }
        }

        public void Desuscribir(IObserverIdioma observador)
        {
            if (_observadores.Contains(observador))
            {
                _observadores.Remove(observador);
            }
        }

        public void Notificar()
        {
            foreach (var obs in _observadores)
            {
                obs.ActualizarIdioma(_diccionarioActual);
            }
        }
        public void CambiarIdioma(int idIdioma)
        {
            _diccionarioActual = _dalIdioma.ObtenerDiccionario(idIdioma);
            Notificar();
        }
    }
}

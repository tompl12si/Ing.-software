﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;
namespace services
{
    public static class BitacoraManager
    {

        public static void Registrar(int IdUsuario, string accion, string detalle)
        {
            DalBitacora dalbitacora = new DalBitacora();
            dalbitacora.RegistrarEvento(IdUsuario, accion, detalle);
        }

        public static DataTable ObtenerRegistros()
        {
            DalBitacora dalbitacora = new DalBitacora();
            return dalbitacora.LeerBitacora();
        }
    }
}

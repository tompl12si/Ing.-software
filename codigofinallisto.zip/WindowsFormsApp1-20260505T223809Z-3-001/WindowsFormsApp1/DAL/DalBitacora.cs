﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class DalBitacora
    {
        private string cadenaconexion = "Data Source=localhost\\SQLEXPRESS;Initial Catalog=Campo;Integrated Security=True";
        
        public void RegistrarEvento(int idusuario, string accion, string detalle)
        {
            using (SqlConnection conexion = new SqlConnection(cadenaconexion))
            {
                conexion.Open();
                string query = "insert into Bitacora (Id_Usuario, Accion, Detalle) values (@Id_Usuario, @Accion, @Detalle)";
                using (SqlCommand cmd = new SqlCommand(query, conexion))
                {
                    cmd.Parameters.AddWithValue("@Id_Usuario", idusuario);
                    cmd.Parameters.AddWithValue("@Accion", accion);
                    cmd.Parameters.AddWithValue("@Detalle", detalle);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public DataTable LeerBitacora()
        {
            DataTable grilla = new DataTable();
            using (SqlConnection conexion = new SqlConnection(cadenaconexion))
            {
                conexion.Open();
                string query = @" 
                    select 
                    b.Fecha,
                    u.Nombre as usuario,
                    b.Accion,
                    b.Detalle
                    from Bitacora b
                    Inner join Usuario u on b.Id_Usuario = u.Id
                    order by b.Fecha DESC
                    ";
                using (SqlCommand cmd = new SqlCommand(query, conexion))
                {
                    using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                    {
                        adapter.Fill(grilla);
                    }
                }

                return grilla;
            }
        }
    }
}

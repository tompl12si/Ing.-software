﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;
namespace services
{
    public static class DigitoVerificador
    {
        private static long CalcularValorAtributo(string texto, int posicionAtributo)
        {
            long sumaCaracteres = 0;
            for (int i = 0; i < texto.Length; i++)
            {
                int posicionCaracter = i + 1;
                int codigoAscii = (int)texto[i];
                sumaCaracteres += (codigoAscii * posicionCaracter);
            }
            return sumaCaracteres * posicionAtributo;
        }
        public static long CalcularDVHUsuario(int id, string nombre, string contraseña, bool activo)
        {
            long v1 = CalcularValorAtributo(id.ToString(), 1);
            long v2 = CalcularValorAtributo(nombre, 2);
            long v3 = CalcularValorAtributo(contraseña, 3);
            long v4 = CalcularValorAtributo(activo.ToString(), 4);

            return v1 + v2 + v3 + v4;
        }
    }
}


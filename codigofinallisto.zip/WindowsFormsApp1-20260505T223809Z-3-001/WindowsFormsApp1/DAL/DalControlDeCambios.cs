﻿using ENTIDADES;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class DalControlDeCambios
    {
        private string cadenaconexion = "Data Source=localhost\\SQLEXPRESS;Initial Catalog=Campo;Integrated Security=True";
        public Usuario ObtenerUsuarioPorId(int id)
        {
            using (SqlConnection conexion = new SqlConnection(cadenaconexion))
            {
                conexion.Open();
                string query = "SELECT Id, Nombre, Contraseña, Activo FROM Usuario WHERE Id = @Id";
                using (SqlCommand cmd = new SqlCommand(query, conexion))
                {
                    cmd.Parameters.AddWithValue("@Id", id);
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            Usuario u = new Usuario();
                            u.id_usuario = Convert.ToInt32(reader["Id"]);
                            u.nombre = reader["Nombre"].ToString();
                            u.contraseña = reader["Contraseña"].ToString();
                            u.activo = Convert.ToBoolean(reader["Activo"]);
                            return u;
                        }
                    }
                }
            }
            return null;
        }
        public void GuardarHistorial(int idAfectado, string nombreAnt, string passAnt, bool activoAnt, int idResponsable, string tipoOp)
        {
            using (SqlConnection conexion = new SqlConnection(cadenaconexion))
            {
                conexion.Open();
                string query = @"
            INSERT INTO Usuario_Historial 
            (Id_Usuario_Afectado, Nombre_Anterior, Contraseña_Anterior, Activo_Anterior, Id_Usuario_Responsable, Tipo_Operacion)
            VALUES (@IdAfectado, @Nombre, @Pass, @Activo, @IdResp, @TipoOp)";

                using (SqlCommand cmd = new SqlCommand(query, conexion))
                {
                    cmd.Parameters.AddWithValue("@IdAfectado", idAfectado);
                    cmd.Parameters.AddWithValue("@Nombre", nombreAnt);
                    cmd.Parameters.AddWithValue("@Pass", passAnt);
                    cmd.Parameters.AddWithValue("@Activo", activoAnt);
                    cmd.Parameters.AddWithValue("@IdResp", idResponsable);
                    cmd.Parameters.AddWithValue("@TipoOp", tipoOp);

                    cmd.ExecuteNonQuery();
                }
            }
        }
        public DataTable ObtenerHistorialPorUsuario(int idUsuarioAfectado)
        {
            DataTable tabla = new DataTable();
            using (SqlConnection conexion = new SqlConnection(cadenaconexion))
            {
                conexion.Open();
                string query = @"
            SELECT Id_Historial, Nombre_Anterior, Contraseña_Anterior, Activo_Anterior, 
                   Id_Usuario_Responsable, Fecha_Cambio, Tipo_Operacion
            FROM Usuario_Historial
            WHERE Id_Usuario_Afectado = @Id
            ORDER BY Fecha_Cambio DESC";

                using (SqlCommand cmd = new SqlCommand(query, conexion))
                {
                    cmd.Parameters.AddWithValue("@Id", idUsuarioAfectado);
                    using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                    {
                        adapter.Fill(tabla); 
                    }
                }
            }
            return tabla;
        }

    }
}

﻿using DAL;
using ENTIDADES;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class BllIdioma
    {
        private DalIdioma dalIdioma = new DalIdioma();

        public List<Idioma> ObtenerIdiomas()
        {
            return dalIdioma.ObtenerIdiomas();
        }

        public Dictionary<string, string> ObtenerDiccionario(int idIdioma)
        {
            return dalIdioma.ObtenerDiccionario(idIdioma);
        }
    }
}

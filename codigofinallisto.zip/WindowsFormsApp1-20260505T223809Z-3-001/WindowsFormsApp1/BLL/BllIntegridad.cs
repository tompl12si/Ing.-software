﻿using DAL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ENTIDADES;
using services;
namespace BLL
{
    public class BllIntegridad
    {
        public bool VerificarIntegridadUsuario()
        {
            DalUsuario dalUser = new DalUsuario();
            long dvvRegistrado = dalUser.ObtenerDVV("Usuario");

       
            if (dvvRegistrado == 0)
            {
                InicializarDigitosPorPrimeraVez();
                return true; 
            }

           
            DataTable dtUsuarios = dalUser.LeerUsuariosTodos();
            long sumaDVHCalculados = 0;

            foreach (DataRow fila in dtUsuarios.Rows)
            {
                int id = Convert.ToInt32(fila["Id"]);
                string nombre = fila["Nombre"].ToString(); 
                string pass = fila["Contraseña"].ToString();
                bool activo = Convert.ToBoolean(fila["Activo"]);
                long dvhRegistrado = Convert.ToInt64(fila["DVH"]);

                long dvhCalculado = DigitoVerificador.CalcularDVHUsuario(id, nombre, pass, activo);

                if (dvhCalculado != dvhRegistrado)
                {
                    return false; 
                }

                sumaDVHCalculados += dvhRegistrado;
            }

            if (sumaDVHCalculados != dvvRegistrado)
            {
                return false; 
            }

            return true;
        }
        private void InicializarDigitosPorPrimeraVez()
        {
            DalUsuario dalUser = new DalUsuario();
            DataTable dtUsuarios = dalUser.LeerUsuariosTodos();
            long sumaTotalDVH = 0;

            foreach (DataRow fila in dtUsuarios.Rows)
            {
                int id = Convert.ToInt32(fila["Id"]);
                string nombre = fila["Nombre"].ToString();
                string pass = fila["Contraseña"].ToString();
                bool activo = Convert.ToBoolean(fila["Activo"]);
                long dvhCalculado = DigitoVerificador.CalcularDVHUsuario(id, nombre, pass, activo);
                dalUser.ActualizarDVH(id, dvhCalculado);

                sumaTotalDVH += dvhCalculado;
            }
            dalUser.ActualizarDVV("Usuario", sumaTotalDVH);
        }
    }
}
  

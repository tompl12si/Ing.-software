﻿using DAL;
using ENTIDADES;
using services;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
     public class BllControlDeCambios
    {
        public void RestaurarUsuario(int idUsuario, string nombreViejo, string passVieja, bool activoViejo, int idadmin)
        {
            DalUsuario dalUsuario = new DalUsuario();
            DalControlDeCambios dalcontroldecambios = new DalControlDeCambios();
            Usuario usuarioactual = dalcontroldecambios.ObtenerUsuarioPorId(idUsuario);
            dalcontroldecambios.GuardarHistorial(idUsuario, nombreViejo, passVieja, activoViejo, idadmin, "RESTAURACION");
            dalUsuario.ActualizarTodo(idUsuario, nombreViejo, passVieja, activoViejo);
            long dvhRestaurado = DigitoVerificador.CalcularDVHUsuario(idUsuario, nombreViejo, passVieja, activoViejo);
            dalUsuario.ActualizarDVH(idUsuario, dvhRestaurado);
            DataTable dtTodos = dalUsuario.LeerUsuariosTodos();
            long nuevaSumaDVV = 0;
            foreach (DataRow fila in dtTodos.Rows)
            {
                nuevaSumaDVV += Convert.ToInt64(fila["DVH"]);
            }
            dalUsuario.ActualizarDVV("Usuario", nuevaSumaDVV);
            BitacoraManager.Registrar(idadmin, "RESTAURACION", $"Se restauró el usuario con ID {idUsuario} a su estado anterior.");
        }
        public DataTable ObtenerHistorialPorUsuario(int id)
        {
            if (string.IsNullOrEmpty(id.ToString()))
            {
                throw new Exception("ID VACIO O NULO");
            }
            else
            {
                DalControlDeCambios dalControlDeCambios = new DalControlDeCambios();
                return dalControlDeCambios.ObtenerHistorialPorUsuario(id);
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ENTIDADES
{
    public class Traduccion
    {
        public int IdiomaId { get; set; }
        public string ClaveControl { get; set; }
        public string Texto { get; set; }
    }
}

﻿using services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class MenuCliente : Form
    {
        public MenuCliente()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            AbrirFormularioEnPanel(new FormGrillaActivos());
        }
        public void AbrirFormularioEnPanel(object formHijo)
        {
            if (this.panelContenedor.Controls.Count > 0)
            {
                this.panelContenedor.Controls.RemoveAt(0);
            }
            Form fh = formHijo as Form;

            fh.TopLevel = false;
            fh.Dock = DockStyle.Fill;
            fh.FormBorderStyle = FormBorderStyle.None;

            this.panelContenedor.Controls.Add(fh);
            this.panelContenedor.Tag = fh;
            fh.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            DialogResult respuesta = MessageBox.Show(
                "¿Estas seguro que queres cerrar la sesion?",
                "Confirmacion",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
                );
            if (respuesta == DialogResult.Yes)
            {
                BitacoraManager.Registrar(SessionManager.instance.UsuarioLogueado.id_usuario, "LOGOUT", $"El usuario {SessionManager.instance.UsuarioLogueado.nombre} cerro la sesion de forma manual");
                SessionManager.instance.CerrarSesion();
                Form1 form = (Form1)Application.OpenForms["form1"];
                if (form != null)
                {
                    form.Show();
                    this.Close();
                }
            }
        }
    }
}

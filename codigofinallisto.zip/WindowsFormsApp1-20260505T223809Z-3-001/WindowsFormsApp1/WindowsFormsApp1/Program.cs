﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using BLL; // Nos aseguramos de importar tu capa de negocio

namespace WindowsFormsApp1
{
    internal static class Program
    {
        /// <summary>
        /// Punto de entrada principal para la aplicación.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            try
            {
                BllIntegridad bllIntegridad = new BllIntegridad();
                if (bllIntegridad.VerificarIntegridadUsuario())
                {
                    Application.Run(new Form1()); 
                }
                else
                {
                    
                    MessageBox.Show(
                        "¡ALERTA CRÍTICA DE SEGURIDAD!\n\n" +
                        "Se ha detectado una falla de integridad (DVH/DVV) en la tabla de Usuarios.\n" +
                        "Los datos sufrieron alteraciones externas al sistema.\n\n" +
                        "El software se cerrará por proteccion",
                        "Error Grave de Integridad",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error
                    );
                    Application.Exit();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al conectar con la base de datos durante el chequeo inicial: {ex.Message}",
                                "Error de Inicio", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                Application.Exit();
            }
        }
    }
}
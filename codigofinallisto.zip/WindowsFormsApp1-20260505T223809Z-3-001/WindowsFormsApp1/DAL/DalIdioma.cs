﻿using ENTIDADES;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class DalIdioma
    {
        private string cadenaconexion = "Data Source=localhost\\SQLEXPRESS;Initial Catalog=campo;Integrated Security=True";
        public List<Idioma> ObtenerIdiomas()
        {
            List<Idioma> lista = new List<Idioma>();
            using (SqlConnection conexion = new SqlConnection(cadenaconexion))
            {
                conexion.Open();
                string query = "SELECT Id, Nombre, PorDefecto FROM Idioma";
                using (SqlCommand cmd = new SqlCommand(query, conexion))
                {
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Idioma i = new Idioma
                            {
                                Id = Convert.ToInt32(reader["Id"]),
                                Nombre = reader["Nombre"].ToString(),
                                PorDefecto = Convert.ToBoolean(reader["PorDefecto"])
                            };
                            lista.Add(i);
                        }
                    }
                }
            }
            return lista;
        }
        public Dictionary<string, string> ObtenerDiccionario(int idIdioma)
        {
            Dictionary<string, string> diccionario = new Dictionary<string, string>();

            using (SqlConnection conexion = new SqlConnection(cadenaconexion))
            {
                conexion.Open();
                string query = "SELECT Clave_Control, Texto FROM Traduccion WHERE Idioma_Id = @IdiomaId";

                using (SqlCommand cmd = new SqlCommand(query, conexion))
                {
                    cmd.Parameters.AddWithValue("@IdiomaId", idIdioma);

                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            string clave = reader["Clave_Control"].ToString();
                            string texto = reader["Texto"].ToString();
                            if (!diccionario.ContainsKey(clave))
                            {
                                diccionario.Add(clave, texto);
                            }
                        }
                    }
                }
            }
            return diccionario;
        }
    }
}

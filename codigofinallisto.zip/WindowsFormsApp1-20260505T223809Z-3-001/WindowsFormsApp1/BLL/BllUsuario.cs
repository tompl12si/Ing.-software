﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ENTIDADES;
using DAL;
using services;
using System.Data;
namespace BLL
{
    public class BllUsuario
    {
        private DalUsuario dalUsuario = new DalUsuario();
        private DalBitacora dalbitacora = new DalBitacora();
        private DalControlDeCambios dalcontroldecambios = new DalControlDeCambios();
        public void altausuario(Usuario usuario)
        {
            if (string.IsNullOrWhiteSpace(usuario.nombre) || string.IsNullOrWhiteSpace(usuario.contraseña))
            {
                throw new Exception("el usuario y la contrasena son campos obligatorio");
            }
            if (dalUsuario.ExisteUsuario(usuario.nombre))
            {
                throw new Exception("EL Nombre de usuario ya existe");
            }

           
            usuario.contraseña = HasheaClaves.HashearClave(usuario.contraseña);
            usuario.activo = true; 
            int idGenerado = dalUsuario.AltaUsuario(usuario);
            usuario.id_usuario = idGenerado;
            long dvhNuevo = DigitoVerificador.CalcularDVHUsuario(usuario.id_usuario, usuario.nombre, usuario.contraseña, usuario.activo);
            dalUsuario.ActualizarDVH(usuario.id_usuario, dvhNuevo);
            RecalcularDVVGeneral();
        }
        public void IniciarSesion(string nombre, string contraseña)
        {
            if (string.IsNullOrWhiteSpace(nombre) || string.IsNullOrWhiteSpace(contraseña))
            {
                throw new Exception("el usuario y la contrasena son campos obligatorio");
            }

            Usuario usuariovalidado = dalUsuario.ValidarIngreso(nombre, HasheaClaves.HashearClave(contraseña));
            
            if(usuariovalidado == null)
            {
                throw new Exception("el usuario o la contraseña son incorrectos");
            }
            
            SessionManager.instance.UsuarioLogueado = usuariovalidado;
            SessionManager.instance.RolActual = dalUsuario.ObtenerRolPorUsuarioId(usuariovalidado.id_usuario);
            dalbitacora.RegistrarEvento(usuariovalidado.id_usuario, "LOGIN EXITOSO", $"El usuario {usuariovalidado.nombre} ingreso al sistema");
        }
        public DataTable ObtenerUsuarios()
        {
            return dalUsuario.LeerUsuarios();
        }
        public DataTable ObtenerUsuariosDadosDeBaja()
        {
            return dalUsuario.LeerUsuariosDadosDeBaja();
        }

        public void ModificarUsuario(int id, string NombreAnterior, string NombreCambio)
        {
            if (string.IsNullOrWhiteSpace(NombreCambio))
            {
                throw new Exception("El nombre de usuario no puede estar vacío.");
            }
            if (dalUsuario.ExisteUsuario(NombreCambio))
            {
                throw new Exception("Ese nombre de usuario ya esta en uso. elegi otro");
            }
            Usuario usuarioviejo = dalcontroldecambios.ObtenerUsuarioPorId(id);
            dalcontroldecambios.GuardarHistorial(usuarioviejo.id_usuario, usuarioviejo.nombre, usuarioviejo.contraseña, usuarioviejo.activo, SessionManager.instance.UsuarioLogueado.id_usuario, "MODIFICACION");
            BitacoraManager.Registrar(SessionManager.instance.UsuarioLogueado.id_usuario, "Modificacion de Usuario/Nombre", $"El usuario con id {SessionManager.instance.UsuarioLogueado.id_usuario} cambio el usuario/nombre del usuario con id:{id} de {NombreAnterior} a {NombreCambio}");
            dalUsuario.ModificarUsuario(id, NombreCambio);
            long dvhNuevo = DigitoVerificador.CalcularDVHUsuario(id, NombreCambio, usuarioviejo.contraseña, usuarioviejo.activo);
            dalUsuario.ActualizarDVH(id, dvhNuevo);
            RecalcularDVVGeneral();
        }
        public void BajaUsuario(int id)
        {
            if (string.IsNullOrEmpty(id.ToString()))
            {
                throw new Exception("El id esta vacio");
            }
            if(id != SessionManager.instance.UsuarioLogueado.id_usuario)
            {
                Usuario usuarioviejo = dalcontroldecambios.ObtenerUsuarioPorId(id);
                dalcontroldecambios.GuardarHistorial(usuarioviejo.id_usuario, usuarioviejo.nombre, usuarioviejo.contraseña, usuarioviejo.activo, SessionManager.instance.UsuarioLogueado.id_usuario, "BAJA");
                BitacoraManager.Registrar(SessionManager.instance.UsuarioLogueado.id_usuario, "Baja de usuario", $"se dio de baja el usuario con id: {id}");
                dalUsuario.BajaUsuario(id);
                long dvhNuevo = DigitoVerificador.CalcularDVHUsuario(id, usuarioviejo.nombre, usuarioviejo.contraseña, false);
                dalUsuario.ActualizarDVH(id, dvhNuevo);
                RecalcularDVVGeneral();
            }
            else
            {
                throw new Exception("No se puede dar de baja el usuario logueado");
            }
        }
        private void RecalcularDVVGeneral()
        {
            DataTable dtTodos = dalUsuario.LeerUsuariosTodos();
            long nuevaSumaDVV = 0;
            foreach (DataRow fila in dtTodos.Rows)
            {
                nuevaSumaDVV += Convert.ToInt64(fila["DVH"]);
            }
            dalUsuario.ActualizarDVV("Usuario", nuevaSumaDVV);
        }

    }
}

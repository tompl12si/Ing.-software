﻿using ENTIDADES;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace services
{
    public class SessionManager
    {
        private static SessionManager _instance;

        public Usuario UsuarioLogueado { get; set; }
        public string RolActual { get; set; }
        private SessionManager()
        {
        }
        public static SessionManager instance
        {
            get
            {
                if(_instance == null)
                {
                    _instance = new SessionManager();
                }
                return _instance;
            }
        }

        public void CerrarSesion()
        {
            UsuarioLogueado = null;
            RolActual  = null;
        }
    }
}

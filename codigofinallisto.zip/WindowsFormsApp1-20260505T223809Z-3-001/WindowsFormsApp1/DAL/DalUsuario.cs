﻿using ENTIDADES;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
     
    public class DalUsuario
    {
        string cadenaconexion = "Data Source=localhost\\SQLEXPRESS;Initial Catalog=Campo;Integrated Security=True";

        public bool ExisteUsuario(string nombreUsuario)
        {
            using (SqlConnection conexion = new SqlConnection(cadenaconexion))
            {
                conexion.Open();
                string query = "SELECT COUNT(*) FROM Usuario WHERE Nombre = @user";
                SqlCommand comando = new SqlCommand(query, conexion);
                comando.Parameters.AddWithValue("@user", nombreUsuario);

                int cantidad = Convert.ToInt32(comando.ExecuteScalar());
                return cantidad > 0;
            }
        }
        public int AltaUsuario(Usuario usuario)
        {
            using (SqlConnection conexion = new SqlConnection(cadenaconexion))
            {
                conexion.Open();
                string query = @"INSERT INTO Usuario (Nombre, Contraseña) 
                        Values (@Nombre, @Contraseña);
                        DECLARE @NuevoUsuarioId int = SCOPE_IDENTITY();
                        INSERT INTO Usuario_Roles(UsuarioId, RolId)
                        Values(@NuevoUsuarioId, 1);
                        SELECT @NuevoUsuarioId;";

                using (SqlCommand cmd = new SqlCommand(query, conexion))
                {
                    cmd.Parameters.AddWithValue("@Nombre", usuario.nombre);
                    cmd.Parameters.AddWithValue("@Contraseña", usuario.contraseña);
                    int idGenerado = Convert.ToInt32(cmd.ExecuteScalar());
                    return idGenerado;
                }
            }
        }
        public void BajaUsuario(int Id_Usuario)
        {
            using (SqlConnection conexion = new SqlConnection(cadenaconexion))
            {
                conexion.Open();
                string query = "Update Usuario set Activo = 0 where Id = @Id_Usuario";
                using (SqlCommand cmd = new SqlCommand(query, conexion))
                {
                    cmd.Parameters.AddWithValue("@Id_Usuario", Id_Usuario);
                    cmd.ExecuteNonQuery();
                }
                conexion.Close();
            }
        }
        public void ModificarUsuario(int id, string NombreCambio)
        {
            using (SqlConnection conexion = new SqlConnection(cadenaconexion))
            {
                conexion.Open();
                string query = "Update Usuario set Nombre = @NombreCambio where Id = @Id";
                using (SqlCommand cmd = new SqlCommand(query, conexion))
                {
                    cmd.Parameters.AddWithValue("@Id", id);
                    cmd.Parameters.AddWithValue("@NombreCambio", NombreCambio);
                    cmd.ExecuteNonQuery();
                }
                conexion.Close();
            }
        }

        public Usuario ValidarIngreso(string usuario, string contraseña)
        {
            using (SqlConnection conexion = new SqlConnection(cadenaconexion))
            {
                conexion.Open();
                string query =" Select Id, Nombre from Usuario where Nombre = @Nombre and Contraseña = @contraseña and Activo = 1";
                SqlCommand cmd = new SqlCommand(query, conexion);
                cmd.Parameters.AddWithValue("@Nombre", usuario);
                cmd.Parameters.AddWithValue("@contraseña", contraseña);
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        Usuario user = new Usuario();
                        user.id_usuario = Convert.ToInt32(reader["Id"]);
                        user.nombre = reader["Nombre"].ToString();
                        return user;
                    }
                }
            }
            return null;
        }

        public DataTable LeerUsuarios()
        {
            DataTable grilla = new DataTable();
            using (SqlConnection conexion = new SqlConnection(cadenaconexion))
            {
                conexion.Open();
                string query = @" 
                    select 
                    u.Id,
                    u.Nombre as usuario
                    from Usuario u
                    where u.Activo = 1
                    ";
                using (SqlCommand cmd = new SqlCommand(query, conexion))
                {
                    using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                    {
                        adapter.Fill(grilla);
                    }
                }

                return grilla;
            }
        }

        public string ObtenerRolPorUsuarioId(int id)
        {
            string rolName = "Cliente";
            using (SqlConnection conexion = new SqlConnection(cadenaconexion))
            {
                conexion.Open();
                string query = @"
                    SELECT r.Nombre
                    FROM Usuario u
                    INNER JOIN Usuario_Roles ur ON u.Id = ur.UsuarioId
                    INNER JOIN Roles r ON ur.RolId = r.Id
                    WHERE u.Id = @IdUsuario";
                using (SqlCommand cmd = new SqlCommand(query, conexion))
                {
                    cmd.Parameters.AddWithValue("@IdUsuario", id);
                    object result = cmd.ExecuteScalar();
                    if (result != null)
                    {
                        rolName = result.ToString();
                    }
                }
            }
            return rolName;
        }
        public void ActualizarTodo(int id, string nombre, string contraseña, bool activo)
        {
            
            using (SqlConnection conexion = new SqlConnection(cadenaconexion))
            {
                conexion.Open();
                string query = @"
            UPDATE Usuario 
            SET Nombre = @Nombre, 
                Contraseña = @Contraseña, 
                Activo = @Activo 
            WHERE Id = @Id";

                using (SqlCommand cmd = new SqlCommand(query, conexion))
                {
                
                    cmd.Parameters.AddWithValue("@Id", id);
                    cmd.Parameters.AddWithValue("@Nombre", nombre);
                    cmd.Parameters.AddWithValue("@Contraseña", contraseña);
                    cmd.Parameters.AddWithValue("@Activo", activo);
                    cmd.ExecuteNonQuery();
                }
            }
        }
        public DataTable LeerUsuariosDadosDeBaja()
        {
            DataTable grilla = new DataTable();
            using (SqlConnection conexion = new SqlConnection(cadenaconexion))
            {
                conexion.Open();
                string query = @" 
                    select 
                    u.Id,
                    u.Nombre as usuario
                    from Usuario u
                    where u.Activo = 0
                    ";
                using (SqlCommand cmd = new SqlCommand(query, conexion))
                {
                    using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                    {
                        adapter.Fill(grilla);
                    }
                }

                return grilla;
            }
        }
        public DataTable LeerUsuariosTodos()
        {
            DataTable grilla = new DataTable();
            using (SqlConnection conexion = new SqlConnection(cadenaconexion))
            {
                conexion.Open();
                string query = @" 
                    SELECT 
                    Id,
                    Nombre,
                    Contraseña,
                    Activo,
                    DVH
                    FROM Usuario";
                using (SqlCommand cmd = new SqlCommand(query, conexion))
                {
                    using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                    {
                        adapter.Fill(grilla);
                    }
                }

                return grilla;
            }
        }
        public long ObtenerDVV(string nombreTabla)
        {
            long dvv = 0;
            using (SqlConnection conexion = new SqlConnection(cadenaconexion))
            {
                conexion.Open();
                string query = "SELECT Valor_DVV FROM Tabla_DVV WHERE Nombre_Tabla = @NombreTabla";

                using (SqlCommand cmd = new SqlCommand(query, conexion))
                {
                    cmd.Parameters.AddWithValue("@NombreTabla", nombreTabla);

                    object resultado = cmd.ExecuteScalar(); 

                    if (resultado != null && resultado != DBNull.Value)
                    {
                        dvv = Convert.ToInt64(resultado);
                    }
                }
            }
            return dvv;
        }
        public void ActualizarDVV(string nombreTabla, long nuevoValorDVV)
        {
            using (SqlConnection conexion = new SqlConnection(cadenaconexion))
            {
                conexion.Open();
                string query = "UPDATE Tabla_DVV SET Valor_DVV = @NuevoValor WHERE Nombre_Tabla = @NombreTabla";

                using (SqlCommand cmd = new SqlCommand(query, conexion))
                {
                    cmd.Parameters.AddWithValue("@NuevoValor", nuevoValorDVV);
                    cmd.Parameters.AddWithValue("@NombreTabla", nombreTabla);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public void ActualizarDVH(int id, long nuevoDVH)
        {
            using (SqlConnection conexion = new SqlConnection(cadenaconexion))
            {
                conexion.Open();
                string query = "UPDATE Usuario SET DVH = @DVH WHERE Id = @Id";
                using (SqlCommand cmd = new SqlCommand(query, conexion))
                {
                    cmd.Parameters.AddWithValue("@DVH", nuevoDVH);
                    cmd.Parameters.AddWithValue("@Id", id);

                    cmd.ExecuteNonQuery();
                }
            }
        }

    }
}

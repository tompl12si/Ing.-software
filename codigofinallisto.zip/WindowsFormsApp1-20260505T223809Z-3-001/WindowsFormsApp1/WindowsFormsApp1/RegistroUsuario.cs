﻿using BLL;
using ENTIDADES;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class RegistroUsuario : Form
    {
        public RegistroUsuario()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Usuario usuario = new Usuario();
            try
            {
                if (textBox2.Text == textBox3.Text)
                {
                    usuario.nombre = textBox1.Text;
                    usuario.contraseña = textBox2.Text;
                    BllUsuario bllusuario = new BllUsuario();
                    bllusuario.altausuario(usuario);
                    textBox1.Clear();
                    textBox2.Clear();
                    textBox3.Clear();
                    MessageBox.Show("Usuario registrado correctamente");
                }
                else
                {
                    MessageBox.Show("Las contraseñas no coinciden");
                }
                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 form = new Form1();
            form.Show();
            this.Hide();
        }
    }
}

﻿using ENTIDADES;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Servicios
{
    public class SessionManager
    {
        private static SessionManager _instance;
        private static readonly object _lock = new object();
        Usuario UsuarioLogueado;
        DateTime FechaIngreso;
        private SessionManager()
        {

        }
        
        public static SessionManager Instance
        {
            get
            {
                if(_instance == null)
                {
                    _instance = new SessionManager();
                }
                return _instance;
            }
        }
    }
}

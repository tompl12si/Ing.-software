﻿using ENTIDADES;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using services;
using BLL;
namespace WindowsFormsApp1
{
    public partial class Form1 : Form, IObserverIdioma
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            IdiomaManager.Instancia.Suscribir(this);
            try
            {
                BllIdioma bllIdioma = new BllIdioma();
                List<Idioma> listaIdiomas = bllIdioma.ObtenerIdiomas();
                cmbIdiomas.DataSource = listaIdiomas;
                cmbIdiomas.DisplayMember = "Nombre";
                cmbIdiomas.ValueMember = "Id";
                foreach (Idioma idioma in listaIdiomas)
                {
                    if (idioma.PorDefecto)
                    {
                        cmbIdiomas.SelectedValue = idioma.Id;
                        IdiomaManager.Instancia.CambiarIdioma(idioma.Id);
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar idiomas: " + ex.Message);
            }
        }
        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            IdiomaManager.Instancia.Desuscribir(this);
        }
        private void button1_Click(object sender, EventArgs e)
        {
              try
            {
                BllUsuario bllUsuario = new BllUsuario();
                bllUsuario.IniciarSesion(textBox1.Text, textBox2.Text);
                if (SessionManager.instance.RolActual == "Cliente")
                {
                    MenuCliente FormCliente = new MenuCliente();
                    FormCliente.Show();
                    this.Hide();
                    textBox1.Clear();
                    textBox2.Clear();
                }
                else if (SessionManager.instance.RolActual == "Admin")
                {
                    MenuAdmin FormAdmin = new MenuAdmin();
                    FormAdmin.Show();
                    this.Hide();
                    textBox1.Clear();
                    textBox2.Clear();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                textBox2.Clear();
                textBox2.Focus();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            RegistroUsuario formregistro = new RegistroUsuario();
            formregistro.Show();
            this.Hide();
            textBox1.Clear();
            textBox2.Clear();
        }
        public void ActualizarIdioma(Dictionary<string, string> traducciones)
        {
            TraducirControles(this.Controls, traducciones);
            if (traducciones.ContainsKey(this.Name))
            {
                this.Text = traducciones[this.Name];
            }
        }
        private void TraducirControles(Control.ControlCollection controles, Dictionary<string, string> traducciones)
        {
            foreach (Control control in controles)
            {
                if (traducciones.ContainsKey(control.Name))
                {
                    control.Text = traducciones[control.Name];
                }
                if (control.HasChildren)
                {
                    TraducirControles(control.Controls, traducciones);
                }
            }
        }

        private void cmbIdiomas_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            if (cmbIdiomas.SelectedValue != null && cmbIdiomas.SelectedValue is int)
            {
                int idIdiomaSeleccionado = (int)cmbIdiomas.SelectedValue;
                IdiomaManager.Instancia.CambiarIdioma(idIdiomaSeleccionado);
            }
        }
    }
}

﻿namespace WindowsFormsApp1
{
    partial class FormGestionarUsuarios
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.botonmodificarusuario = new System.Windows.Forms.Button();
            this.botonbajausuario = new System.Windows.Forms.Button();
            this.botonverhistorialdecambios = new System.Windows.Forms.Button();
            this.botonmostrarusuariosdadosdebaja = new System.Windows.Forms.Button();
            this.botonmostrarusuariosdadosdealta = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(-1, -1);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 62;
            this.dataGridView1.RowTemplate.Height = 28;
            this.dataGridView1.Size = new System.Drawing.Size(665, 452);
            this.dataGridView1.TabIndex = 0;
            // 
            // botonmodificarusuario
            // 
            this.botonmodificarusuario.Location = new System.Drawing.Point(670, 12);
            this.botonmodificarusuario.Name = "botonmodificarusuario";
            this.botonmodificarusuario.Size = new System.Drawing.Size(151, 38);
            this.botonmodificarusuario.TabIndex = 1;
            this.botonmodificarusuario.Text = "Modificar Usuario";
            this.botonmodificarusuario.UseVisualStyleBackColor = true;
            this.botonmodificarusuario.Click += new System.EventHandler(this.button1_Click);
            // 
            // botonbajausuario
            // 
            this.botonbajausuario.Location = new System.Drawing.Point(670, 56);
            this.botonbajausuario.Name = "botonbajausuario";
            this.botonbajausuario.Size = new System.Drawing.Size(151, 49);
            this.botonbajausuario.TabIndex = 2;
            this.botonbajausuario.Text = "Baja Usuario";
            this.botonbajausuario.UseVisualStyleBackColor = true;
            this.botonbajausuario.Click += new System.EventHandler(this.button2_Click);
            // 
            // botonverhistorialdecambios
            // 
            this.botonverhistorialdecambios.Location = new System.Drawing.Point(671, 111);
            this.botonverhistorialdecambios.Name = "botonverhistorialdecambios";
            this.botonverhistorialdecambios.Size = new System.Drawing.Size(145, 68);
            this.botonverhistorialdecambios.TabIndex = 3;
            this.botonverhistorialdecambios.Text = "Ver Historial de Cambios";
            this.botonverhistorialdecambios.UseVisualStyleBackColor = true;
            this.botonverhistorialdecambios.Click += new System.EventHandler(this.button3_Click);
            // 
            // botonmostrarusuariosdadosdebaja
            // 
            this.botonmostrarusuariosdadosdebaja.Location = new System.Drawing.Point(670, 185);
            this.botonmostrarusuariosdadosdebaja.Name = "botonmostrarusuariosdadosdebaja";
            this.botonmostrarusuariosdadosdebaja.Size = new System.Drawing.Size(151, 82);
            this.botonmostrarusuariosdadosdebaja.TabIndex = 4;
            this.botonmostrarusuariosdadosdebaja.Text = "Mostrar Usuarios Dados de Baja";
            this.botonmostrarusuariosdadosdebaja.UseVisualStyleBackColor = true;
            this.botonmostrarusuariosdadosdebaja.Click += new System.EventHandler(this.button4_Click);
            // 
            // botonmostrarusuariosdadosdealta
            // 
            this.botonmostrarusuariosdadosdealta.Location = new System.Drawing.Point(827, 185);
            this.botonmostrarusuariosdadosdealta.Name = "botonmostrarusuariosdadosdealta";
            this.botonmostrarusuariosdadosdealta.Size = new System.Drawing.Size(135, 82);
            this.botonmostrarusuariosdadosdealta.TabIndex = 5;
            this.botonmostrarusuariosdadosdealta.Text = "Mostrar Usuarios Dados de Alta";
            this.botonmostrarusuariosdadosdealta.UseVisualStyleBackColor = true;
            this.botonmostrarusuariosdadosdealta.Click += new System.EventHandler(this.button5_Click);
            // 
            // FormGestionarUsuarios
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(974, 450);
            this.Controls.Add(this.botonmostrarusuariosdadosdealta);
            this.Controls.Add(this.botonmostrarusuariosdadosdebaja);
            this.Controls.Add(this.botonverhistorialdecambios);
            this.Controls.Add(this.botonbajausuario);
            this.Controls.Add(this.botonmodificarusuario);
            this.Controls.Add(this.dataGridView1);
            this.Name = "FormGestionarUsuarios";
            this.Text = "FormGestionarUsuarios";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.FormGestionarUsuarios_FormClosed);
            this.Load += new System.EventHandler(this.FormGestionarUsuarios_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button botonmodificarusuario;
        private System.Windows.Forms.Button botonbajausuario;
        private System.Windows.Forms.Button botonverhistorialdecambios;
        private System.Windows.Forms.Button botonmostrarusuariosdadosdebaja;
        private System.Windows.Forms.Button botonmostrarusuariosdadosdealta;
    }
}
﻿using BLL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using services;
namespace WindowsFormsApp1
{
    public partial class FormGestionarUsuarios : Form, IObserverIdioma
    {
        public FormGestionarUsuarios()
        {
            InitializeComponent();
            FormUsuarios_Load();
        }
        private void FormGestionarUsuarios_Load(object sender, EventArgs e)
        {
            IdiomaManager.Instancia.Suscribir(this);
        }
        private void FormGestionarUsuarios_FormClosed(object sender, FormClosedEventArgs e)
        {
            IdiomaManager.Instancia.Desuscribir(this);
        }
        public void ActualizarIdioma(Dictionary<string, string> traducciones)
        {
            TraducirControles(this.Controls, traducciones);

            if (traducciones.ContainsKey(this.Name))
            {
                this.Text = traducciones[this.Name];
            }
        }
        private void TraducirControles(Control.ControlCollection controles, Dictionary<string, string> traducciones)
        {
            foreach (Control control in controles)
            {
                if (traducciones.ContainsKey(control.Name))
                {
                    control.Text = traducciones[control.Name];
                }
                if (control.HasChildren)
                {
                    TraducirControles(control.Controls, traducciones);
                }
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                int IdSeleccionado = Convert.ToInt32(dataGridView1.CurrentRow.Cells["Id"].Value);
                string nombreActual = dataGridView1.CurrentRow.Cells["usuario"].Value.ToString();
                string NuevoNombre = Interaction.InputBox("Ingrese el nuevo nombre de usuario:", "Modificar Usuario", "");
                if (!string.IsNullOrEmpty(NuevoNombre) && NuevoNombre != nombreActual)
                {
                    BllUsuario bllUsuario = new BllUsuario();
                    bllUsuario.ModificarUsuario(IdSeleccionado, nombreActual, NuevoNombre);
                    FormUsuarios_Load();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void FormUsuarios_Load()
        {
            BllUsuario bllUsuario = new BllUsuario();
            try
            {
                dataGridView1.DataSource = null;
                dataGridView1.DataSource = bllUsuario.ObtenerUsuarios();
                dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                dataGridView1.ReadOnly = true;
                dataGridView1.AllowUserToAddRows = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar la bitacora: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void FormUsuarios_LoadDadosDeBaja()
        {
            BllUsuario bllUsuario = new BllUsuario();
            try
            {
                dataGridView1.DataSource = null;
                dataGridView1.DataSource = bllUsuario.ObtenerUsuariosDadosDeBaja();
                dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                dataGridView1.ReadOnly = true;
                dataGridView1.AllowUserToAddRows = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar la bitacora: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            BllUsuario bllUsuario = new BllUsuario();
            try
            {
                int IdSeleccionado = Convert.ToInt32(dataGridView1.CurrentRow.Cells["Id"].Value);
                string nombreActual = dataGridView1.CurrentRow.Cells["usuario"].Value.ToString();
                string mensaje = $"¿Estas seguro que queres dar de baja al usuario {nombreActual}?";
                DialogResult respuesta = MessageBox.Show(
                mensaje,
                "Confirmar Baja",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
                );
                if (respuesta == DialogResult.Yes)
                {
                    try
                    {
                        bllUsuario.BajaUsuario(IdSeleccionado);
                        FormUsuarios_Load();
                    }
                    catch(Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if(dataGridView1.CurrentRow == null)
            {
                MessageBox.Show("POR FAVOR, SELECCIONA UN USUARIO DE LA LISTA");            
            }
            else
            {
                int IdSeleccionado = Convert.ToInt32(dataGridView1.CurrentRow.Cells["Id"].Value);
                FormControlDeCambios formControlDeCambios = new FormControlDeCambios(IdSeleccionado);
                formControlDeCambios.ShowDialog();
                FormUsuarios_Load();
            }

            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                FormUsuarios_LoadDadosDeBaja();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                FormUsuarios_Load();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}

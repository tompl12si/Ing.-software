﻿using BLL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using services;
namespace WindowsFormsApp1
{
    public partial class FormControlDeCambios : Form
    {
        private int IdUsuarioSeleccionado;
        private BllControlDeCambios bllControlDeCambios = new BllControlDeCambios();
        public FormControlDeCambios(int id)
        {
            InitializeComponent();
            IdUsuarioSeleccionado = id;
            FormHIstorial_load(id);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (dataGridView1.CurrentRow == null)
                {
                    MessageBox.Show("selecciona una version");
                }
                else
                {
                    DialogResult respuesta = MessageBox.Show($"¿Estás seguro de querer devolver este usuario a su estado anterior'?", "Confirmar Restauración", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                    if(respuesta == DialogResult.Yes)
                    {
                        BllControlDeCambios bllControlDeCambios = new BllControlDeCambios();
                        string nombreanterior = dataGridView1.CurrentRow.Cells["Nombre_Anterior"].Value.ToString();
                        string passvieja = dataGridView1.CurrentRow.Cells["Contraseña_Anterior"].Value.ToString();
                        bool activoviejo = Convert.ToBoolean(dataGridView1.CurrentRow.Cells["Activo_Anterior"].Value);
                        bllControlDeCambios.RestaurarUsuario(IdUsuarioSeleccionado, nombreanterior, passvieja, activoviejo, SessionManager.instance.UsuarioLogueado.id_usuario);
                        MessageBox.Show("USUARIO REGRESADO A SU ESTADO ANTERIOR CON EXITO");
                        this.Close();
                    }
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void FormHIstorial_load(int id)
        {
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = bllControlDeCambios.ObtenerHistorialPorUsuario(id);
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridView1.ReadOnly = true;
            dataGridView1.AllowUserToAddRows = false;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ENTIDADES
{
    public class Idioma
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
        public bool PorDefecto { get; set; }
    }
}

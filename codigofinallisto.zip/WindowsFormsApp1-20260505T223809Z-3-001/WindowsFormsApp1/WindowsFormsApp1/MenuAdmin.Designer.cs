﻿namespace WindowsFormsApp1
{
    partial class MenuAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.botoncerrarsesionadmin = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.botongestionarusuario = new System.Windows.Forms.Button();
            this.botonbitacora = new System.Windows.Forms.Button();
            this.botondefault = new System.Windows.Forms.Button();
            this.panelContenedor = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // botoncerrarsesionadmin
            // 
            this.botoncerrarsesionadmin.Location = new System.Drawing.Point(939, 0);
            this.botoncerrarsesionadmin.Name = "botoncerrarsesionadmin";
            this.botoncerrarsesionadmin.Size = new System.Drawing.Size(186, 50);
            this.botoncerrarsesionadmin.TabIndex = 0;
            this.botoncerrarsesionadmin.Text = "Cerrar Sesion";
            this.botoncerrarsesionadmin.UseVisualStyleBackColor = true;
            this.botoncerrarsesionadmin.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.botoncerrarsesionadmin);
            this.panel1.Controls.Add(this.botongestionarusuario);
            this.panel1.Controls.Add(this.botonbitacora);
            this.panel1.Controls.Add(this.botondefault);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1125, 53);
            this.panel1.TabIndex = 1;
            // 
            // botongestionarusuario
            // 
            this.botongestionarusuario.Location = new System.Drawing.Point(523, 0);
            this.botongestionarusuario.Name = "botongestionarusuario";
            this.botongestionarusuario.Size = new System.Drawing.Size(421, 50);
            this.botongestionarusuario.TabIndex = 2;
            this.botongestionarusuario.Text = "Gestionar Usuario";
            this.botongestionarusuario.UseVisualStyleBackColor = true;
            this.botongestionarusuario.Click += new System.EventHandler(this.button4_Click);
            // 
            // botonbitacora
            // 
            this.botonbitacora.Location = new System.Drawing.Point(194, 0);
            this.botonbitacora.Name = "botonbitacora";
            this.botonbitacora.Size = new System.Drawing.Size(329, 50);
            this.botonbitacora.TabIndex = 1;
            this.botonbitacora.Text = "Bitacora";
            this.botonbitacora.UseVisualStyleBackColor = true;
            this.botonbitacora.Click += new System.EventHandler(this.button3_Click);
            // 
            // botondefault
            // 
            this.botondefault.Location = new System.Drawing.Point(0, 0);
            this.botondefault.Name = "botondefault";
            this.botondefault.Size = new System.Drawing.Size(199, 53);
            this.botondefault.TabIndex = 0;
            this.botondefault.Text = "Default";
            this.botondefault.UseVisualStyleBackColor = true;
            this.botondefault.Click += new System.EventHandler(this.button2_Click);
            // 
            // panelContenedor
            // 
            this.panelContenedor.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelContenedor.Location = new System.Drawing.Point(0, 53);
            this.panelContenedor.Name = "panelContenedor";
            this.panelContenedor.Size = new System.Drawing.Size(1125, 631);
            this.panelContenedor.TabIndex = 2;
            this.panelContenedor.Paint += new System.Windows.Forms.PaintEventHandler(this.panelContenedor_Paint);
            // 
            // MenuAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1125, 684);
            this.Controls.Add(this.panelContenedor);
            this.Controls.Add(this.panel1);
            this.Name = "MenuAdmin";
            this.Text = "MenuCliente";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.MenuAdmin_FormClosed);
            this.Load += new System.EventHandler(this.MenuAdmin_Load);
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button botoncerrarsesionadmin;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button botongestionarusuario;
        private System.Windows.Forms.Button botonbitacora;
        private System.Windows.Forms.Button botondefault;
        private System.Windows.Forms.Panel panelContenedor;
    }
}
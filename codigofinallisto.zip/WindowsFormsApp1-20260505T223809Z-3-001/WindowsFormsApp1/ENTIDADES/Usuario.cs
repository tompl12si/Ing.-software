﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace ENTIDADES
{
    public class Usuario
    {
        private string Nombre;
        private int Id_Usuario;
        private string Contraseña;
        private bool Activo;
        public bool activo
        {
            get { return Activo; }
            set { Activo = value; }
        }
        public string nombre
        {
            get { return Nombre; }
            set { Nombre = value; }
        }
        public int id_usuario
        {
            get { return Id_Usuario; }
            set { Id_Usuario = value; }
        }
        public string contraseña
        {
            get { return Contraseña; }
            set { Contraseña = value; }
        }
    }
}
